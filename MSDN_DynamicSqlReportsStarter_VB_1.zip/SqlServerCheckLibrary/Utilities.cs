﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SqlServerCheckLibrary
{
    /// <summary>
    /// Permits checking if a server and database exists.
    /// </summary>
    public class Utilities
    {
        string exceptionMessage;
        public string ExceptionMessage { get { return exceptionMessage; } }
        bool hasException;
        public bool HasException { get { return hasException; } }

        /// <summary>
        /// Determine if a specific SQL-Server is available
        /// </summary>
        /// <param name="pServerName">Server name to work with</param>
        /// <returns></returns>
        public async Task<bool> SqlServerIsAvailable(string pServerName)
        {
            bool success = false;

            try
            {
                await Task.Run(() =>
                {
                    SqlDataSourceEnumerator sqlDataSourceEnumeratorInstance = SqlDataSourceEnumerator.Instance;
                    DataTable dt = sqlDataSourceEnumeratorInstance.GetDataSources();
                    if (dt != null)
                    {
                        if (dt.Rows.Count > 0)
                        {
                            var row = dt.AsEnumerable().FirstOrDefault(r => r.Field<string>("ServerName") == pServerName.ToUpper());
                            success = row != null;
                        }
                        else
                        {
                            success = false;
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                hasException = true;
                exceptionMessage = ex.Message;
            }

            return success;
        }
        /// <summary>
        /// Determines if a catalog/database exist on a specific instance of SQL-Server
        /// </summary>
        /// <param name="pServer"></param>
        /// <param name="pDatabase"></param>
        /// <returns></returns>
        public async Task<bool> DatabaseExists(string pServer, string pDatabase)
        {
            bool success = false;
            var testServer = await SqlServerIsAvailable(pServer);
            if (!testServer)
            {
                return false;
            }

            try
            {
                using (SqlConnection cn = new SqlConnection { ConnectionString = ("Data Source=" + (pServer + ";Initial Catalog=master;Integrated Security=True;")) })
                {
                    using (SqlCommand cmd = new SqlCommand { Connection = cn, CommandText = ("select * from master.dbo.sysdatabases where name='" + (pDatabase + "'")) })
                    {
                        cn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        success = reader.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                hasException = true;
                exceptionMessage = ex.Message;
            }

            return success;

        }
        /// <summary>
        /// Get table names for a database that exists on an available SQL-Server
        /// </summary>
        /// <param name="pServer">Server name</param>
        /// <param name="pDatabase">Database name</param>
        /// <returns></returns>
        public List<string> TableNames(string pServer, string pDatabase)
        {
            var tableNames = new List<string>();
            var _ConnectionString = $"Data Source={pServer};Initial Catalog={pDatabase};Integrated Security=True";

            using (SqlConnection cn = new SqlConnection { ConnectionString = _ConnectionString })
            {
                using (SqlCommand cmd = new SqlCommand() { Connection = cn })
                {
                    cmd.CommandText =
                            @"SELECT s.name, o.name
                              FROM sys.objects o WITH(NOLOCK)
                              JOIN sys.schemas s WITH(NOLOCK)
                              ON o.schema_id = s.schema_id
                              WHERE o.is_ms_shipped = 0 AND RTRIM(o.type) = 'U'
                              ORDER BY s.name ASC, o.name ASC";

                    cn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {

                            string tableName = reader.GetString(1);
                            if (!tableName.Contains("sysdiagrams"))
                            {
                                tableNames.Add(tableName);
                            }

                        }
                    }
                }
            }

            return tableNames;
        }
    }
}
