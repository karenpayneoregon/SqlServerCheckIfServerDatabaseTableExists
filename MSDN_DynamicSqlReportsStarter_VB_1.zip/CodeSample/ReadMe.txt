﻿This solution began life to demostrate storing dynamic sql in several slq table where the code sample
may be found here https://code.msdn.microsoft.com/Dynamic-SQL-stored-in-SQL-154692ec?redir=0

This modified version is to show how to 
	* Check if the server name (SQL-Server instance) is available
	* Determine if the catalog exists on the server
	* various assertions to protect against users entering invalid SQL or parameter information.

For the first two bullets I scavanged code from a code sample I did in C# https://code.msdn.microsoft.com/SQL-Server-check-if-server-1f53886f
and saw no good reason to convert it to vb.net as if you think about it, VB developers use C# functionality every time they code via
native .NET Framework classes. This is no different unless you wanted to modifiy the code which should not be needed.

No full well that adding the first two bullets will slow down things but since they are asynchronous the user interface remains responsive
yet there is nothing the user can do. I used a cheezie splash screen, a panel which is hidden when data is loaded or there is an exception.

