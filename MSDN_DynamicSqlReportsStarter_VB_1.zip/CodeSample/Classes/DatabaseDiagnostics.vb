﻿Imports SqlServerCheckLibrary
Public Class DatabaseDiagnostics
    Private mHasException As Boolean
    Public ReadOnly Property HasException As Boolean
        Get
            Return mHasException
        End Get
    End Property
    Private mException As Exception
    Public ReadOnly Property LastException As Exception
        Get
            Return mException
        End Get
    End Property

    Private mServerName As String
    Private mCatalog As String
    Private mExceptionMessage As String = ""

    Private mErrors As String
    Public ReadOnly Property Errors As String
        Get
            Return mErrors
        End Get
    End Property
    Private mTableNames As List(Of String)
    Public ReadOnly Property TableNames As List(Of String)
        Get
            Return mTableNames
        End Get
    End Property
    ''' <summary>
    ''' Check if server, database and tables exists.
    ''' </summary>
    ''' <param name="pServerName">Server name to check if exists</param>
    ''' <param name="pCatalog">Catalog to check if exists on pServerName</param>
    Public Sub New(ByVal pServerName As String, ByVal pCatalog As String)
        mServerName = pServerName
        mCatalog = pCatalog
    End Sub
    Public Async Function Check() As Task(Of Boolean)
        Dim sb As New Text.StringBuilder

        Try
            Dim checker As New Utilities

            If Not Await checker.SqlServerIsAvailable(mServerName) Then
                sb.AppendLine($"Server '{mServerName}' not found.")
            End If

            If Not Await checker.DatabaseExists(mServerName, mCatalog) Then
                sb.AppendLine($"'{mServerName}.{mCatalog}' table not found")
            End If

            If sb.Length > 0 Then
                mErrors = sb.ToString
            Else
                mTableNames = checker.TableNames(mServerName, mCatalog)
            End If

            Return Not sb.Length > 0

        Catch ex As Exception
            mHasException = True
            mException = ex
            Return False
        End Try


    End Function

End Class
