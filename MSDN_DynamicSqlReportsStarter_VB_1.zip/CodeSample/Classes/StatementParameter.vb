﻿Public Class StatementParameter
    ''' <summary>
    ''' Parameter Name 
    ''' </summary>
    ''' <returns></returns>
    Public Property Name As String
    ''' <summary>
    ''' Parameter value
    ''' </summary>
    ''' <returns></returns>
    Public Property Value As Object
End Class