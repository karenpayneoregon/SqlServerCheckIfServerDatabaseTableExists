﻿* Make sure to change the server name in DataOperations ConnectionString property to match your server name.
* If the Form1 does not display, close it, build the solution (this builds the custom panel) then the form will open.
* All classes could reside in a separate class project so the code can be used in other projects outside of this solution.