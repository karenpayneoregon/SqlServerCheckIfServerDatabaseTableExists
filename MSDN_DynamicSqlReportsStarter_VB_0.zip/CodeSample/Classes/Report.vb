﻿''' <summary>
''' Report from database
''' </summary>
Public Class Report
    Public Property Id As Integer
    Public Property Name As String
    Public Property Description As String
    Public Property Statement As String
    Public Property StatementId As Integer
End Class
