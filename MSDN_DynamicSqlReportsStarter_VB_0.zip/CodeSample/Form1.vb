﻿''' <summary>
''' Please note that the SQL has no syntax highlighting but if you don't mind looking at the following
''' code sample I did in VB.NET and used a C# library to syntax highlight SQL then you are good to go
''' https://code.msdn.microsoft.com/Reveal-parameter-values-28725e53?redir=0
''' </summary>
Public Class Form1
    Private ops As New DataOperations
    Private bsReports As New BindingSource
    ''' <summary>
    ''' Setup data sources and subscribe to our events
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bsReports.DataSource = ops.GetReportList
        ListBox1.DataSource = bsReports
        ListBox1.DisplayMember = "Name"

        TextBox1.DataBindings.Add("Text", bsReports, "Statement")
        Label1.DataBindings.Add("Text", bsReports, "Description")


        AddHandler bsReports.PositionChanged, AddressOf PositonChanged
        getParameters(CType(bsReports.Current, Report).StatementId)

    End Sub
    ''' <summary>
    ''' Get current SQL statement for current row.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub PositonChanged(sender As Object, e As EventArgs)
        getParameters(CType(bsReports.Current, Report).StatementId)
    End Sub
    ''' <summary>
    ''' Get parameters for selected report with values
    ''' </summary>
    ''' <param name="pId">Statement primary key</param>
    Private Sub getParameters(ByVal pId As Integer)
        DataGridView1.Rows.Clear()
        Dim params = ops.Parameters(pId)

        For Each p As StatementParameter In params
            DataGridView1.Rows.Add(New Object() {p.Name, p.Value})
        Next

    End Sub
    ''' <summary>
    ''' Pass query, parameters with values to create SELECT statement and run
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub executeScriptButton_Click(sender As Object, e As EventArgs) Handles executeScriptButton.Click

        Dim paramList As New List(Of StatementParameter)

        For Each row As DataGridViewRow In DataGridView1.Rows

            paramList.Add(New StatementParameter With
                {
                  .Name = row.Cells(0).Value.ToString,
                  .Value = row.Cells(1).Value
                })

        Next

        Dim f As New ResultsForm
        f.DataGridView1.DataSource = ops.Execute(TextBox1.Text, paramList)

        Try
            f.ShowDialog()
        Finally
            f.Dispose()
        End Try

    End Sub
End Class
